def add (a, b):
    return a + b

def average(numbers):
    return sum(numbers) / len(numbers)