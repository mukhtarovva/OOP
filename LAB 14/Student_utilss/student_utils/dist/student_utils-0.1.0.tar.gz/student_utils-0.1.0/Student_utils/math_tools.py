def add (a, b):
    return a + b

def avarage(numbers):
    return sum(numbers) / len(numbers)